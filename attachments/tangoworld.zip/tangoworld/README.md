# TangoWorld 🐾

TangoWorld es un juego de mascota virtual hecho con React, Vite y Three.js. La habitación y sus objetos son geometría 3D sencilla; la mascota se representa con los PNG transparentes originales incluidos en `public/assets/pets/`.

## Requisitos

- Node.js 16.18 o superior (Node 18 LTS recomendado).
- npm.

## Ejecutar en local

1. Descomprime el proyecto.
2. Abre una terminal dentro de la carpeta `tangoworld`.
3. Ejecuta:

   ```bash
   npm install
   npm run dev
   ```

4. Abre la URL local que muestre Vite, normalmente `http://localhost:5173`.

Para crear la versión de producción:

```bash
npm run build
npm run preview
```

La carpeta `dist/` resultante contiene la app compilada. No hay backend, cuentas ni servicios externos necesarios. Después de compilar, las funciones esenciales y los PNG se sirven localmente; el guardado permanece en el navegador mediante `localStorage`.

## Cómo jugar

- **Comida:** abre tu inventario y utiliza croquetas, manzana o galletitas.
- **Dormir:** activa el descanso; el nivel de sueño se recupera progresivamente. Pulsa otra vez para despertar.
- **Salud:** usa un botiquín desde la acción de salud o desde la mochila.
- **Baño:** utiliza jabón y completa las tres acciones para limpiar a la mascota.
- **Jugar:** elige uno de los tres minijuegos. Cada uno entrega monedas al cobrar la recompensa.
- **Tienda:** compra comida, jabón, botiquines y juguetes con monedas del juego.
- **Vestidor:** desbloquea y equipa cualquiera de las diez apariencias PNG.
- **Recompensas:** las acciones de cuidado pueden dar +2 monedas, con un límite de una recompensa de cuidado cada 90 segundos; además, recoge 12 monedas de regalo diario y gana monedas en los minijuegos.
- **Sonido:** usa el botón de altavoz para silenciar o reactivar los efectos sencillos.
- **Configuración:** puedes reiniciar la partida; se pide confirmación antes de borrar el progreso.

## Controles de los minijuegos

- **Atrapa las estrellas:** flechas izquierda/derecha, A/D, arrastrar dentro del juego o botones táctiles. Recoge estrellas y evita piedras.
- **Parejas mágicas:** toca dos cartas por turno para encontrar los seis pares.
- **Carrera de obstáculos:** barra espaciadora, flecha arriba, toque en el recorrido o botón **SALTAR**.

## Guardado y tiempo

Las estadísticas, monedas, inventario, apariencias, descanso y momento de la última sesión se guardan automáticamente en este navegador. Al volver, el juego calcula el tiempo transcurrido, con un máximo de 12 horas de progreso offline por sesión. Las estadísticas siempre quedan limitadas al rango 0–100. La mascota no muere y no se pierde la partida por descuidarla.

## Estructura

```text
tangoworld/
├── public/assets/pets/    # 10 PNG originales de la mascota
├── src/
│   ├── game/GameScene.jsx # habitación 3D y sprite transparente
│   ├── App.jsx            # interfaz, guardado, economía y minijuegos
│   ├── main.jsx           # punto de entrada de React
│   └── styles.css         # interfaz responsive
├── index.html
├── package.json
└── vite.config.js
```

## Notas

- La app requiere instalación inicial de dependencias de npm para desarrollo; no utiliza backend.
- Las puntuaciones, monedas y objetos son locales y no se sincronizan entre navegadores o dispositivos.
- El avance offline está limitado intencionalmente para evitar cambios desproporcionados tras largos periodos.
