import { useEffect, useRef } from 'react';
import * as THREE from 'three';

/** A small, self-contained Three.js room. The pet itself remains a transparent PNG. */
export default function GameScene({ skin, sleeping, action, onPetTap }) {
  const mountRef = useRef(null);
  const tapRef = useRef(onPetTap);
  const actionRef = useRef(action);
  tapRef.current = onPetTap;
  actionRef.current = action;

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return undefined;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(sleeping ? '#d8d9f4' : '#ecebff');
    scene.fog = new THREE.Fog(sleeping ? '#d8d9f4' : '#ecebff', 9, 22);

    const camera = new THREE.PerspectiveCamera(36, 1, 0.1, 100);
    camera.position.set(0, 3.45, 8.6);
    camera.lookAt(0, 1.3, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'low-power' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.8));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.08;
    renderer.domElement.setAttribute('aria-label', 'Habitación tridimensional de TangoWorld. Toca a la mascota para acariciarla.');
    mount.appendChild(renderer.domElement);

    const ambient = new THREE.HemisphereLight('#fff8ff', '#8580b2', 2.05);
    scene.add(ambient);
    const keyLight = new THREE.DirectionalLight('#fff4dc', sleeping ? 1.9 : 2.5);
    keyLight.position.set(-3.8, 7, 4);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.left = -5;
    keyLight.shadow.camera.right = 5;
    keyLight.shadow.camera.top = 6;
    keyLight.shadow.camera.bottom = -3;
    keyLight.shadow.bias = -0.0004;
    scene.add(keyLight);
    const fillLight = new THREE.PointLight('#c6b8ff', 1.1, 12);
    fillLight.position.set(3.3, 3, 1.8);
    scene.add(fillLight);

    const materials = [];
    const geometries = [];
    const addMesh = (geometry, material, position, rotation = null) => {
      geometries.push(geometry);
      materials.push(material);
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(...position);
      if (rotation) mesh.rotation.set(...rotation);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      scene.add(mesh);
      return mesh;
    };

    // Soft pastel room: floor, back wall and a side wall.
    const floor = addMesh(
      new THREE.PlaneGeometry(12, 12),
      new THREE.MeshStandardMaterial({ color: '#f6e9e7', roughness: 0.95 }),
      [0, -0.04, 0], [-Math.PI / 2, 0, 0]
    );
    floor.receiveShadow = true;
    addMesh(new THREE.PlaneGeometry(12, 6), new THREE.MeshStandardMaterial({ color: '#dcd9ff', roughness: 1 }), [0, 2.9, -3.1]);
    addMesh(new THREE.PlaneGeometry(7, 6), new THREE.MeshStandardMaterial({ color: '#cbc8f5', roughness: 1 }), [-5.95, 2.9, 0], [0, Math.PI / 2, 0]);

    // Skirting boards and a few geometric wall decorations.
    addMesh(new THREE.BoxGeometry(12, 0.12, 0.12), new THREE.MeshStandardMaterial({ color: '#b9b2e5', roughness: 0.8 }), [0, 0.11, -3.02]);
    const wallDecorMat = new THREE.MeshStandardMaterial({ color: '#fff8db', roughness: 0.75 });
    addMesh(new THREE.CircleGeometry(0.34, 32), wallDecorMat, [-2.7, 2.45, -3.02]);
    addMesh(new THREE.CircleGeometry(0.19, 32), new THREE.MeshStandardMaterial({ color: '#ffbdc9', roughness: 0.8 }), [-2.7, 2.45, -2.99]);
    addMesh(new THREE.TorusGeometry(0.38, 0.055, 8, 32), new THREE.MeshStandardMaterial({ color: '#fffaf0', roughness: 0.8 }), [2.55, 2.25, -3.02]);

    // Bed on the left.
    addMesh(new THREE.BoxGeometry(1.7, 0.28, 1.1), new THREE.MeshStandardMaterial({ color: '#7e82db', roughness: 0.8 }), [-1.8, 0.28, -0.72]);
    addMesh(new THREE.BoxGeometry(1.62, 0.13, 1.02), new THREE.MeshStandardMaterial({ color: '#b9bbff', roughness: 0.95 }), [-1.8, 0.47, -0.72]);
    addMesh(new THREE.BoxGeometry(0.52, 0.13, 0.44), new THREE.MeshStandardMaterial({ color: '#fff5d9', roughness: 0.9 }), [-2.19, 0.57, -0.77]);
    // Food bowl on the right.
    addMesh(new THREE.CylinderGeometry(0.36, 0.27, 0.2, 32, 1, true), new THREE.MeshStandardMaterial({ color: '#ff9eaa', roughness: 0.5, side: THREE.DoubleSide }), [1.72, 0.2, 0.62]);
    addMesh(new THREE.CylinderGeometry(0.27, 0.27, 0.045, 32), new THREE.MeshStandardMaterial({ color: '#f6c46e', roughness: 0.65 }), [1.72, 0.25, 0.62]);
    // A tiny tiled wash tub at the back of the room.
    addMesh(new THREE.BoxGeometry(0.96, 0.22, 0.72), new THREE.MeshStandardMaterial({ color: '#83cee6', roughness: 0.5 }), [2.65, 0.18, -1.45]);
    addMesh(new THREE.BoxGeometry(0.9, 0.08, 0.65), new THREE.MeshStandardMaterial({ color: '#c5f0fa', roughness: 0.35 }), [2.65, 0.32, -1.45]);
    addMesh(new THREE.BoxGeometry(0.82, 0.035, 0.56), new THREE.MeshStandardMaterial({ color: '#7cbed9', roughness: 0.32, transparent: true, opacity: 0.9 }), [2.65, 0.36, -1.45]);
    // Toy ball and little plant pot.
    const ball = addMesh(new THREE.SphereGeometry(0.22, 20, 16), new THREE.MeshStandardMaterial({ color: '#ffcf6e', roughness: 0.44 }), [2.55, 0.25, -0.25]);
    ball.rotation.z = 0.25;
    addMesh(new THREE.CylinderGeometry(0.2, 0.16, 0.3, 16), new THREE.MeshStandardMaterial({ color: '#e9a1a7', roughness: 0.85 }), [-3.65, 0.16, -1.25]);
    addMesh(new THREE.IcosahedronGeometry(0.28, 0), new THREE.MeshStandardMaterial({ color: '#79c7a6', roughness: 0.8 }), [-3.65, 0.52, -1.25]);
    addMesh(new THREE.IcosahedronGeometry(0.2, 0), new THREE.MeshStandardMaterial({ color: '#8bd7b0', roughness: 0.8 }), [-3.38, 0.54, -1.29]);

    // Grounding shadow beneath the transparent sprite.
    const shadow = new THREE.Mesh(
      new THREE.CircleGeometry(0.68, 40),
      new THREE.MeshBasicMaterial({ color: '#68618e', transparent: true, opacity: 0.19, depthWrite: false })
    );
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.set(0.05, 0.015, 0.28);
    scene.add(shadow);
    geometries.push(shadow.geometry);
    materials.push(shadow.material);

    const petMaterial = new THREE.MeshBasicMaterial({ transparent: true, alphaTest: 0.025, depthWrite: false, side: THREE.DoubleSide });
    materials.push(petMaterial);
    const petGeometry = new THREE.PlaneGeometry(1, 1);
    geometries.push(petGeometry);
    const pet = new THREE.Mesh(petGeometry, petMaterial);
    pet.position.set(0.02, 1.42, 0.23);
    pet.renderOrder = 3;
    scene.add(pet);

    let texture = null;
    let petBaseWidth = 1.3;
    let petBaseHeight = 2.58;
    const loader = new THREE.TextureLoader();
    let textureActive = true;
    loader.load(`/assets/pets/${skin}.png`, (loaded) => {
      if (!textureActive) {
        loaded.dispose();
        return;
      }
      loaded.colorSpace = THREE.SRGBColorSpace;
      loaded.generateMipmaps = true;
      loaded.minFilter = THREE.LinearMipmapLinearFilter;
      loaded.magFilter = THREE.LinearFilter;
      texture = loaded;
      petMaterial.map = loaded;
      petMaterial.needsUpdate = true;
      const aspect = loaded.image.width / loaded.image.height;
      const height = 2.58;
      petBaseWidth = height * aspect;
      petBaseHeight = height;
      pet.scale.set(petBaseWidth, petBaseHeight, 1);
    }, undefined, () => {
      // If an asset fails, the room stays usable rather than crashing.
      petMaterial.color.set('#e8b8c6');
    });

    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    let lastTapAt = 0;
    const onPointerDown = (event) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      if (raycaster.intersectObject(pet, false).length && Date.now() - lastTapAt > 400) {
        lastTapAt = Date.now();
        tapRef.current?.();
      }
    };
    renderer.domElement.addEventListener('pointerdown', onPointerDown);

    let frame = 0;
    let animationId = 0;
    const clock = new THREE.Clock();
    let activeAction = '';
    let actionStarted = 0;
    const resize = () => {
      const width = Math.max(1, mount.clientWidth);
      const height = Math.max(1, mount.clientHeight);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height, false);
    };
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(resize) : null;
    if (observer) observer.observe(mount);
    window.addEventListener('resize', resize);
    resize();

    const animate = () => {
      animationId = requestAnimationFrame(animate);
      const t = clock.getElapsedTime();
      frame += 1;
      const nextAction = actionRef.current || '';
      if (nextAction !== activeAction) { activeAction = nextAction; actionStarted = t; }
      const actionElapsed = t - actionStarted;
      let actionLift = 0;
      let scalePulse = 0;
      let actionLean = 0;
      if (activeAction === 'pet-hop' && actionElapsed < 0.52) actionLift = Math.sin((actionElapsed / 0.52) * Math.PI) * 0.32;
      if (activeAction === 'pet-eat' && actionElapsed < 0.58) scalePulse = Math.sin((actionElapsed / 0.58) * Math.PI * 4) * 0.035;
      if (activeAction === 'pet-bath' && actionElapsed < 0.52) actionLean = Math.sin((actionElapsed / 0.52) * Math.PI * 3) * 0.035;
      pet.position.y = 1.42 + (sleeping ? Math.sin(t * 1.6) * 0.025 : Math.sin(t * 2.25) * 0.055) + actionLift;
      pet.rotation.z = (sleeping ? Math.sin(t * 0.8) * 0.015 : Math.sin(t * 1.2) * 0.018) + actionLean;
      pet.scale.set(petBaseWidth * (1 + scalePulse), petBaseHeight * (1 - scalePulse), 1);
      shadow.scale.setScalar(1 + Math.sin(t * 2.25) * 0.035);
      ball.position.y = 0.25 + Math.abs(Math.sin(t * 1.55)) * 0.035;
      if (frame % 2 === 0) renderer.render(scene, camera);
    };
    animate();

    return () => {
      textureActive = false;
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', resize);
      observer?.disconnect();
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      if (texture) texture.dispose();
      geometries.forEach((g) => g.dispose());
      materials.forEach((m) => m.dispose());
      renderer.dispose();
      renderer.domElement.remove();
    };
  // Recreate the scene when the equipped PNG changes; all previous Three.js resources are disposed.
  }, [skin, sleeping]);

  return <div className="game-scene" ref={mountRef} />;
}
